// 5 kinds of loops

// for      - Iterates a block of code specified number of time
// for/in   - Iterating the properties of an object
// for/of   - Iterating the values of an iterable (string and array) object (ES 2015)
// while    - Iterates a block of code specified condition is true
// do/while - Also Iterates a block of code specified condition is true

// for (let i = 0; i < 5; i++) {
//     console.log("i, ", i);
// }

// for (let i = 0, j = 10; i < 5; i++, j++) {
//     if (i === 2) {
//         // break;
//         continue;
//     }
//     // console.log('i - ' + i + ', j - ' + j);
//     console.log(`i - ${i}, j - ${j}`);
// }

// for (let i = 5; i > 0; i--) {
//     console.log("i, ", i);
// }

// --------------------------------------------------- For In
// var person = { fname: "Manish", lname: "Sharma", city: "Pune" };

// for (const key in person) {
//     console.log(key);
//     console.log(person[key]);
// }

// var numbers = [10, 20, 30, 40, 50, 60, 70, 80];
// var numbers = { 0: 10, 1: 20, 3: 30 };
// console.log(typeof numbers)

// for (let i = 0; i < numbers.length; i++) {
//     console.log(`${i} - ${numbers[i]}`);
// }

// for (const key in numbers) {
//     console.log(`${key} - ${numbers[key]}`);
// }

// ----------------------------------------------------- ES 2015 - For Of
// var numbers = [10, 20, 30, 40, 50, 60, 70, 80];

// // for (const item of numbers) {
// //     console.log(`${item}`);
// // }

// // for (const item of numbers.entries()) {
// //     console.log(`${item[0]} - ${item[1]}`);
// // }

// for (const [index, item] of numbers.entries()) {
//     console.log(`${index} - ${item}`);
// }

// ------------------------------------------------------ While

// var i = 6;

// while (i < 5) {
//     console.log(i);
//     i++;
// }

// // ------------------------------------------------------ Do While

// do {
//     console.log(i);
//     i++;
// } while (i < 5);


// ------------------------------------------------------------- JSON vs JavaScript Object

// var person = { fname: "Manish", lname: "Sharma", city: "Pune" };
// console.log(person);
// console.log(typeof person);

// var person_JSON = JSON.stringify(person);
// console.log(person_JSON);
// console.log(typeof person_JSON);

// ----------------------------------------- Associative Arrays

// var states;
// states["GOA"] = "GA"
// states = { "GOA": "GA" }