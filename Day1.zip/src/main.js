// console.log("Hello from Main");

// import './1_Datatypes/1_Declarations';
// import './1_Datatypes/2_Datatypes';
// import './1_Datatypes/3_ES6_Declarations';
// import './1_Datatypes/4_Scopes';

// import './2_Operators/1_Comparision';
// import './2_Operators/2_Symbols';
// import './2_Operators/3_Conversion';

// import './3_CertainConditions/1_Loops';
// import './3_CertainConditions/2_Statements';

// import './4_Functions/1_FnCreation';
// import './4_Functions/2_FnParameters';
// import './4_Functions/3_RestAndSpread';
import './4_Functions/4_PureAndImpureFn';