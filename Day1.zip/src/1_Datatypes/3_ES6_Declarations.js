// Block Scoped Variables

// let a = 10;
// console.log(a);
// console.log(typeof a);

// Hoisting - Hoisting is not allowed with let keyword

// a = 10;
// console.log(a);
// console.log(typeof a);
// let a;

// var a = 10;
// var a = "Manish";
// console.log(a);

// We cannot recreate a block scoped variable
// let a = 10;
// let a = "Manish";
// console.log(a);

// -------------------------------------------------------------------
// const must be initialized and it cannot be re-initialized

// const env = "development";
// console.log(env);
// console.log(typeof env);

// env = "production";
// console.log(env);
// console.log(typeof env);

const person = { id: 1, name: "Manish" };
console.log(person);

// person.id = 1000;
person = {};            // Assignment to constant variable.

console.log(person);
