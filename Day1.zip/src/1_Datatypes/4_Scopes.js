// // Lexical Scoping

// var a = 10;
// console.log("Global: ", a);

// // function test() {
// //     console.log("Inside test: ", a);
// // }

// // test();

// function test1() {
//     // var a = 100;
//     console.log("Inside test1: ", a);

//     function test2() {
//         // var a = 1000;
//         console.log("Inside test2: ", a);
//     }

//     test2();
// }

// test1();

// // ------------------------------------------------------------ Scopes in ES5
// // Global Scope
// // Function Scope (Local)

// var i = "Hello";
// console.log("Before, i is", i);

// // for (var i = 0; i < 5; i++) {
// //     console.log("Inside Loop, i is", i);
// // }

// // function iterate() {
// //     for (var i = 0; i < 5; i++) {
// //         console.log("Inside Loop, i is", i);
// //     }
// // }

// // iterate();

// // IIFE - Immediatly Invoked Function Expression
// (function () {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside Loop, i is", i);
//     }
// })();

// console.log("After, i is", i);

// ------------------------------------------------------------ Scopes in ES2015 and Above
// Global Scope
// Function Scope (Local)
// Block Scope (Only when we use let or const)

// var i = "Hello";
// console.log("Before, i is", i);

// for (let i = 0; i < 5; i++) {
//     console.log("Inside Loop, i is", i);
// }

// console.log("After, i is", i);

// The callback function will be called after delay of 1 second only once
// setTimeout(function () {
//     console.log("Called....");
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside Loop, i is", i);
//     }
// }, 1000);


for (let i = 0; i < 10; i++) {
    setTimeout(function () {
        console.log("Inside Loop, i is", i);
    }, 1000);
}

