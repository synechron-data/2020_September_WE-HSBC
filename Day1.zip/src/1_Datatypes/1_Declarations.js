// Add 'use strict' manually if wrting the js files
// or
// use @babel/plugin-transform-strict-mode plugin when your are compiling through babel

// 'use strict'
// console.log("Hello from declarations.js");

// a = 10;
// console.log(a);
// console.log(typeof a);

// function test() {
//     var a = 10;
//     console.log("Inside Test, a is", a);
// }

// test();
// console.log("Outside Test, a is", a);

// ---------------------------------------------------------------------
// var a = 10;
// console.log(a);
// console.log(typeof a);

// a = "ABC";
// console.log(a);
// console.log(typeof a);

// Hoisting - Hoisting is JavaScript's default behavior of moving declarations to the top.

// a = 10;
// console.log(a);
// console.log(typeof a);

// var a;

// Initializations are not hoisted
// console.log(a);
// console.log(typeof a);
// var a = 10;

// Runtime will se the below code
// var a;
// console.log(a);
// console.log(typeof a);
// a = 10;

