// Type Casting - Between Similiar (Same Family of) Types       int to float, float to int
// Type Conversion - Diffent Family of types                    int to string, string to int

// var data = window.prompt("Enter a number", 0);
// console.log(typeof data);

// var n1 = data + 10;
// console.log(n1);
// console.log(typeof n1);

// var n1 = parseInt(data) + 10;
// console.log(n1);
// console.log(typeof n1);

// var n1 = parseFloat(data) + 10;
// console.log(n1);
// console.log(typeof n1);

// var n1 = Number(data) + 10;
// console.log(n1);
// console.log(typeof n1);

// var obj = null;
// var obj;
var obj = {};

// if ((obj === null) || (obj === undefined)) {
// if (!obj) {
//     console.log("Is null or undefined...");
// } else {
//     console.log("Is not null or undefined...");
// }

// console.log(Boolean(0))
// console.log(Boolean(1))
// console.log(Boolean(-1))
// console.log(Boolean("ABC"))
// console.log(Boolean(""))
// console.log(Boolean(undefined))
// console.log(Boolean(null))
// console.log(Boolean(Number.NaN))

console.log(true && "ABC")
console.log(true && "ABC" || "XYZ")
console.log(false && "ABC" || "XYZ")

{/* <h1 className={isSelected() && "ABC" || "XYZ"}></h1> */}