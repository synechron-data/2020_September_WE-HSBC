// const Read = "Read";
// const Write = "Write";

// function Open(mode) {
//     if (mode === Read)
//         console.log('File opened in "Read" mode');
//     else if (mode === Write)
//         console.log('File opened in "Write" mode');
//     else
//         console.log('File cannot be opened');
// }

// Open(Read);
// Open(Write);

// Open("Read");
// Open("Write");

// var rMode = "Read";
// var wMode = "Write";
// Open(rMode);
// Open(wMode);

// -------------------------------------------------------
// const Read = { mode: "Read" };
// const Write = { mode: "Write" };

// function Open(mode) {
//     if (mode === Read)
//         console.log('File opened in "Read" mode');
//     else if (mode === Write)
//         console.log('File opened in "Write" mode');
//     else
//         console.log('File cannot be opened');
// }

// Open(Read);
// Open(Write);

// Open({ mode: "Read" });
// Open({ mode: "Write" });

// var rMode = { mode: "Read" };
// var wMode = { mode: "Write" };
// Open(rMode);
// Open(wMode);

// -------------------------------------------------------
const Read = Symbol("Read");
const Write = Symbol("Write");

function Open(mode) {
    if (mode === Read)
        console.log('File opened in "Read" mode');
    else if (mode === Write)
        console.log('File opened in "Write" mode');
    else
        console.log('File cannot be opened');
}

Open(Read);
Open(Write);

Open(Symbol("Read"));
Open(Symbol("Write"));

var rMode = Symbol("Read");
var wMode = Symbol("Write");
Open(rMode);
Open(wMode);