// // ---------------------------------------------------- Object.assign
// let source = { id: 1, name: "Manish", address: { city: "Pune" }, display: function () { } };

// // let target = source;

// // Shallow Copy
// // let target = Object.assign({}, source);
// // target.name = "Abhijeet";
// // target.address.city = "Mumbai";

// // Deep Copy with Functions
// let target = JSON.parse(JSON.stringify(source));
// target.name = "Abhijeet";
// target.address.city = "Mumbai";

// console.log("Source ", source);
// console.log("Target ", target);

// ---------------------------------------------------- Object.create
// Creates a new object, using an existing object as the prototype of the newly created object.

// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// let target1 = Object.assign({}, source);
// let target2 = Object.create(source);

// console.log("Source ", source);
// console.log("Target 1 ", target1);
// console.log("Target 2", target2);

// -------------------------------------------------------

let source = { id: 1, name: "Manish" };

// // Modify Property Value
// source.id = 100;
// console.log(source);

// // Add New Property
// source.city = "Pune";
// console.log(source);

// // Delete Property
// delete source.id;
// console.log(source);

// Object.preventExtensions(source);
// // Modify Property Value - Allowed
// // Add New Property - Not Allowed
// // Delete Property - Allowed

// source.id = 100;
// console.log(source);

// delete source.id;
// console.log(source);

// if (Object.isExtensible(source)) {
//     source.city = "Pune";
//     console.log(source);
// }

// Object.seal(source);
// // Modify Property Value - Allowed
// // Add New Property - Not Allowed
// // Delete Property - Not Allowed

// source.id = 100;
// console.log(source);

// if (!Object.isSealed(source)) {
//     delete source.id;
//     console.log(source);

//     source.city = "Pune";
//     console.log(source);
// }

Object.freeze(source);
// Modify Property Value - Not Allowed
// Add New Property - Not Allowed
// Delete Property - Not Allowed

if (!Object.isFrozen(source)) {
    source.id = 100;
    console.log(source);

    delete source.id;
    console.log(source);

    source.city = "Pune";
    console.log(source);
}
