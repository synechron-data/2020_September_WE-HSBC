// Only one default export allowed per module. 
// Case 1 - Default Export
// export default function square(x) {
//     return x * x;
// }

// Case 2 - Multi Export - Named Exports
// export function square(x) {
//     return x * x;
// }

// export function check(x) {
//     return `Checked ${x}`;
// }


// Case 3 - Named and Default Exports
// export default function square(x) {
//     return x * x;
// }

// export function check(x) {
//     return `Checked ${x}`;
// }

export default class Person {
    constructor(name) {
        this._name = name;
    }

    getName() {
        return this._name;
    }

    setName(name) {
        this._name = name;
    }
}