// import './1_Functions/1_ArrowFn';
// import './1_Functions/2_FnAsArguments';
// import './1_Functions/3_FnOverloading';
// import './1_Functions/4_IIFE';
// import './1_Functions/5_FnContext';
// import './1_Functions/6_Closure';
// import './1_Functions/7_Currying';

// import './2_Types/1_ObjectType';
// import './2_Types/2_ObjectMethods';
// import './2_Types/3_CustomType';
// import './2_Types/4_UsingPrototype';
// import './2_Types/5_ES6_Class';
// import './2_Types/6_Compare';
// import './2_Types/7_ES5_Properties';
// import './2_Types/8_ES6_Properties';
// import './2_Types/9_ES6_StaticMembers';
// import './2_Types/10_ES5_Inheritance';
// import './2_Types/11_ES6_Inheritance';

// import './3_Collections/1_Array';
// import './3_Collections/2_Map';
// import './3_Collections/3_Set';

// import './4_Modules/usage';

// import './5_Promise/1_CreatingPromise';
// import './5_Promise/2_ChainingPromise';
// import './5_Promise/3_PromiseMethods';

import './5_Promise/domHandler';
