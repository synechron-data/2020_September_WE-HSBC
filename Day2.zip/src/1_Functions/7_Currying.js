// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// greetings("Good Morning", "Abhijeet");
// greetings("Good Morning", "Ramakant");
// greetings("Good Morning", "Pravin");

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// console.log(Converter(" INR", 71, 0, 100));
// console.log(Converter(" INR", 71, 0, 150));
// console.log(Converter(" INR", 71, 0, 1000));
// console.log(Converter(" INR", 71, 0, 970));

// ------------------------------------------------------------------------------------
// function greetings(message) {
//     return function (name) {
//         console.log(`${message}, ${name}`);
//     }
// }

// // var mGreet = greetings("Good Morning");

// // mGreet("Abhijeet");
// // mGreet("Ramakant");
// // mGreet("Pravin");

// // var aGreet = greetings("Good Afternoon");

// // aGreet("Abhijeet");
// // aGreet("Ramakant");
// // aGreet("Pravin");

// function Converter(toUnit, factor, offset) {
//     return function (input) {
//         return [((offset + input) * factor).toFixed(2), toUnit].join("");
//     }
// }

// var USDtoINR = Converter(" INR", 71, 0);

// console.log(USDtoINR(100));
// console.log(USDtoINR(150));
// console.log(USDtoINR(1000));
// console.log(USDtoINR(970));

// -------------------------------------------------------------------------------------
function greetings(message, name) {
    console.log(`${message}, ${name}`);
}

var mGreet = greetings.bind(undefined, "Good Morning");

mGreet("Abhijeet");
mGreet("Ramakant");
mGreet("Pravin");

function Converter(toUnit, factor, offset, input) {
    return [((offset + input) * factor).toFixed(2), toUnit].join("");
}

var USDtoINR = Converter.bind(undefined, " INR", 71, 0);

console.log(USDtoINR(100));
console.log(USDtoINR(150));
console.log(USDtoINR(1000));
console.log(USDtoINR(970));