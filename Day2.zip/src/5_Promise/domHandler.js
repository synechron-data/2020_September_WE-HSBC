import apiClient from './apiClient';

var button = document.createElement("button");
button.innerHTML = "Get Data";

var body = document.getElementsByTagName("body")[0];
body.appendChild(button);

button.addEventListener("click", function () {
    // apiClient.getAllPosts((data) => {
    //     console.log("DOM Handler - ", data);
    // }, (eMsg) => {
    //     console.log("DOM Handler - ", eMsg);
    // });

    var p = apiClient.getAllPostsUsingPromise();

    p.then((data) => {
        console.log("DOM Handler - ", data);
    }, (eMsg) => {
        console.log("DOM Handler - ", eMsg);
    });
});

// 1. Call a function
// 2. Pass input data (Mocked)
// 3. Accepts the Promise
// 4. Assert(Result, ExpectedResult)